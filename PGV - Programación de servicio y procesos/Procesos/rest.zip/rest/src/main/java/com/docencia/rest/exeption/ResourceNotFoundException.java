package com.docencia.rest.exeption;


public class ResourceNotFoundException extends Exception {

    public ResourceNotFoundException() {
        super();
    }

    public ResourceNotFoundException(String mensajes) {
        super(mensajes);
    }
        public ResourceNotFoundException(String mensajes,Throwable myException) {
        super(mensajes, myException);
    }
}
